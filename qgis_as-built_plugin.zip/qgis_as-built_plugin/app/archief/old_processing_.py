# qgis imports
from qgis.core import QgsVectorLayer, QgsProject, QgsCoordinateReferenceSystem
import processing


class Processing:
    def crs_corrigeren(self, layer) -> QgsVectorLayer:
        # naam opslaan
        naam = layer.name()

        # processing parameters instellen
        parameters = {
            'INPUT': layer,
            'TARGET_CRS': 'EPSG:31370',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # nieuwe laag aanmaken met correcte crs
        layer = processing.run("native:reprojectlayer", parameters)['OUTPUT']

        # originele naam behouden
        layer.setName(naam)

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(layer)

        return layer

    def merge_layers(self, layers_lijst) -> QgsVectorLayer:
        # naam opslaan
        naam = layers_lijst[0].name()

        # processing parameters instellen
        parameters = {
            'LAYERS': layers_lijst,
            'CRS': 'EPSG:31370',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # meerdere layers mergen tot één layer
        layer = processing.run("native:mergevectorlayers", parameters)['OUTPUT']

        # layer naam instellen
        layer.setName(naam)

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(layer)

        return layer

    def vclean(self, layer) -> QgsVectorLayer:
        # processing parameters instellen
        parameters = {
            'input': layer,
            'type': 1,
            'tool': [11, 12, 0, 6, 2, 1],
            'threshold': '0, 0, 0, 0, 1, 1',
            'output': 'TEMPORARY_OUTPUT',
            'error': 'TEMPORARY_OUTPUT'
        }

        # layer cleanen
        layer = processing.run("grass7:v.clean", parameters)['output']

        # van de output weer een QgsVectorLayer maken
        layer = QgsVectorLayer(layer, 'cleaned')

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(layer)

        return layer

    @staticmethod
    def split_layer(layer) -> dict:
        # processing parameters instellen
        parameters = {
            'INPUT': layer,
            'FIELD': 'layer',
            'PREFIX_FIELD': False,
            'FILE_TYPE': 0,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # layer splitten op basis van een bepaald field
        layers = processing.run("native:splitvectorlayer", parameters)['OUTPUT_LAYERS']

        return layers

    @staticmethod
    def layer_opslaan_in_gpkg(layer) -> None:
        # locatie variabelen instellen
        project_folder = QgsProject.instance().readPath('.')
        gpkg = f'{project_folder}/Asbuilt.gpkg'

        # processing parameters instellen
        parameters = {
            'INPUT': layer,
            'OPTIONS': f'-overwrite -nln "{layer.name()}"',
            'OUTPUT': gpkg
        }

        # processing uitvoeren
        processing.run("gdal:convertformat", parameters)

    def accessnet_facade_met_pop_info(self) -> QgsVectorLayer:
        # variabelen
        accessnet_facade_layer = QgsProject.instance().mapLayersByName('AccessNet_Facade')[0]
        wijkpunten_layer = QgsProject.instance().mapLayersByName('WIJKPUNTEN')[0]

        # processing parameters instellen
        parameters = {
            'INPUT': accessnet_facade_layer,
            'PREDICATE': [5],
            'JOIN': wijkpunten_layer,
            'JOIN_FIELDS': ['DG', 'WP', 'POP'],
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'PREFIX': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run("native:joinattributesbylocation", parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    def hpp_in_wijkpunten(self) -> QgsVectorLayer:
        # variabelen
        hpp_laag = QgsProject.instance().mapLayersByName('HPP')[0]
        wijkpunten_laag = QgsProject.instance().mapLayersByName('WIJKPUNTEN')[0]

        # processing parameters instellen
        parameters = {
            'INPUT': hpp_laag,
            'PREDICATE': [6],
            'INTERSECT': wijkpunten_laag,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run('native:extractbylocation', parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    def hpp_lijnen(self, hpp_laag) -> QgsVectorLayer:
        # variabelen
        straat_laag = QgsProject.instance().mapLayersByName('Z-GRB — ZA. Straten')[0]

        # processing parameters instellen
        parameters = {
            'SOURCE': hpp_laag,
            'DESTINATION': straat_laag,
            'METHOD': 0,
            'NEIGHBORS': 1,
            'DISTANCE': None,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run('native:shortestline', parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    def asbuilt_lagen(self) -> QgsVectorLayer:
        # variabelen
        asbuilt_lagen = [asbuilt_laag for asbuilt_laag in QgsProject.instance().mapLayers().values() if
                         'AccessNet' in asbuilt_laag.name() or 'Drilling' in asbuilt_laag.name()]

        # processing parameters instellen
        parameters = {
            'LAYERS': asbuilt_lagen,
            'CRS': QgsCoordinateReferenceSystem('EPSG:31370'),
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run('native:mergevectorlayers', parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    def hpp(self, hpp_laag, asbuilt_laag) -> QgsVectorLayer:
        # processing parameters instellen
        parameters = {
            'INPUT': hpp_laag,
            'PREDICATE': [7],
            'INTERSECT': asbuilt_laag,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run('native:extractbylocation', parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    def hpp_per_wp(self, hpp_laag) -> QgsVectorLayer:
        # variabelen
        wijkpunten_layer = QgsProject.instance().mapLayersByName('WIJKPUNTEN')[0]

        # processing parameters instellen
        parameters = {
            'INPUT': hpp_laag,
            'PREDICATE': [5],
            'JOIN': wijkpunten_layer,
            'JOIN_FIELDS': ['DG', 'WP', 'POP'],
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'PREFIX': '_',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        resultaat = processing.run("native:joinattributesbylocation", parameters)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(resultaat)

        return resultaat

    @staticmethod
    def indexeren(laag) -> None:
        # processing parameters instellen
        parameters = {
            'INPUT': laag
        }

        # processing uitvoeren
        processing.run('native:createspatialindex', parameters)

    def hpp_zonder_cap_adressen(self, laag) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag,
            'EXPRESSION': 'not("Targetdelivery" = \'CAP\')',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # meerdere layers mergen tot één layer
        extract = processing.run("native:extractbyexpression", instellingen)['OUTPUT']

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(extract)

        return extract

    def facade_per_wp(self, laag, wp) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag,
            'EXPRESSION': f'"DG" + \' \' + "WP" + \' - \' + "POP" = \'{wp}\'',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # meerdere layers mergen tot één layer
        extract = processing.run("native:extractbyexpression", instellingen)['OUTPUT']

        # laagnaam instellen
        extract.setName(f'{wp} - AccessNet_Facade')

        # nieuwe laag indexeren --> versnelt verdere bewerkingen op de laag
        self.indexeren(extract)

        return extract

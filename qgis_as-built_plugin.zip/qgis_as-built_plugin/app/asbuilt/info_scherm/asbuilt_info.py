import os

# qt imports
from qgis.PyQt import QtWidgets, uic

# qgis imports
from qgis.core import QgsApplication, QgsTask, Qgis, QgsMessageLog
from qgis.utils import iface

# interne imports
from .info_inladen import AsbuiltInfo


# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'asbuilt_info.ui'))


class GUI_AsbuiltInfo(QtWidgets.QMainWindow, FORM_CLASS, ):
    def __init__(self, parent=None):
        super(GUI_AsbuiltInfo, self).__init__(parent)
        self.setupUi(self)
        self.btnInfoBerekenen.clicked.connect(self.__info_tonen)
        self.taken = QgsApplication.taskManager()

    def __info_tonen(self):
        asbuilt_info_inladen = AsbuiltInfoInladen(
            'asbuilt info inladen',
            self.btnInfoBerekenen,
            self.lblZone,
            self.lblTrenching,
            self.lblCrossings,
            self.lblFacade,
            self.lblManholes,
            self.lblHPP,
            self.lblBouwstraatHPP
        )

        self.taken.addTask(asbuilt_info_inladen)


class AsbuiltInfoInladen(QgsTask):
    def __init__(self, description, btnInfoBerekenen, lblZone, lblTrenching, lblCrossings, lblFacade,
                 lblManholes, lblHPP, lblBouwstraatHPP):

        super().__init__(description, QgsTask.CanCancel)

        self.__btnInfoBerekenen = btnInfoBerekenen
        self.__lblZone = lblZone
        self.__lblTrenching = lblTrenching
        self.__lblCrossings = lblCrossings
        self.__lblFacade = lblFacade
        self.__lblManholes = lblManholes
        self.__lblHPP = lblHPP
        self.__lblBouwstraatHPP = lblBouwstraatHPP

    def run(self):
        self.__knop_uitschakelen()

        info = AsbuiltInfo()

        self.__lblZone.setText(info.zone_naam)
        self.__lblTrenching.setText(str(info.trenching))
        self.__lblCrossings.setText(str(info.crossings))
        self.__lblFacade.setText(str(info.facade))
        self.__lblManholes.setText(str(info.manholes))
        self.__lblHPP.setText(str(info.hpp))
        self.__lblBouwstraatHPP.setText(str(info.bouwstraatHPP))

        return True

    def finished(self, result):
        self.__knop_inschakelen()

        # indien de selectie niet correct was een error bericht tonen
        if self.__lblZone.text() == '':
            iface.messageBar().pushMessage("Error", "Ongeldige selectie", level=Qgis.Warning)

    def __knop_uitschakelen(self):
        self.__btnInfoBerekenen.setText('Bliep Bloep Bliep ...')
        self.__btnInfoBerekenen.setEnabled(False)

    def __knop_inschakelen(self):
        self.__btnInfoBerekenen.setText('Info berekenen')
        self.__btnInfoBerekenen.setEnabled(True)

# hulp imports
import sys
import subprocess
import os


class OngekendeModule:
    def __init__(self, naam: str):
        self.__naam: str = naam

    def installeren(self) -> None:
        # osgeo4w shell openenen en module installeren
        subprocess.check_call([self.__osgeo_shell_path(), 'python', '-m', 'pip', 'install', self.__naam])

    @staticmethod
    def __osgeo_shell_path() -> str:

        # locatie van osgeo4w.bat zoeken
        program_files = os.environ["ProgramFiles"]
        qgis_folder = [f.name for f in os.scandir(program_files) if f.is_dir() and 'QGIS ' in f.name][-1]
        osgeo_shell = 'OSGeo4W.bat'

        # locatie van osgeo4w.bat samenstellen
        path_osgeo_shell = f'{program_files}/{qgis_folder}/{osgeo_shell}'

        return path_osgeo_shell

# qgis imports
from qgis.core import QgsVectorLayer, QgsProject, QgsCoordinateReferenceSystem
import processing


class Processing:
    def __processing_uitvoeren(self, instellingen: dict, algoritme: str, output: bool = True,
                               spatial_index_creeeren: bool = True):
        # processing uitvoeren
        resultaat = processing.run(f'native:{algoritme}', instellingen)

        if spatial_index_creeeren:
            # spatial index creeeren --> versnelt de volgende bewerkingen op de resultaat laag
            self.__create_spatial_index(resultaat['OUTPUT'])

        if output:
            return resultaat['OUTPUT']

        return None

    def __create_spatial_index(self, laag) -> None:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag
        }

        # processing uitvoeren
        self.__processing_uitvoeren(instellingen, 'createspatialindex', False, False)

    def split_with_lines(self, laag1: QgsVectorLayer, laag2: QgsVectorLayer) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag1,
            'LINES': laag2,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        return self.__processing_uitvoeren(instellingen, 'splitwithlines')

    def extract_by_location(self, laag1: QgsVectorLayer, laag2: QgsVectorLayer, opties: list = [0]) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag1,
            'PREDICATE': opties,
            'INTERSECT': laag2,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        return self.__processing_uitvoeren(instellingen, 'extractbylocation')

    def extract_by_expression(self, laag: QgsVectorLayer, filter_expressie: str):
        # processing parameters instellen
        instellingen = {
            'INPUT': laag,
            'EXPRESSION': filter_expressie,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        return self.__processing_uitvoeren(instellingen, 'extractbyexpression')

    def shortest_line(self, laag1: QgsVectorLayer, laag2: QgsVectorLayer) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'SOURCE': laag1,
            'DESTINATION': laag2,
            'METHOD': 0,
            'NEIGHBORS': 1,
            'DISTANCE': None,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        return self.__processing_uitvoeren(instellingen, 'shortestline')

    def merge_vector_layers(self, lagen: list) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'LAYERS': lagen,
            'CRS': QgsCoordinateReferenceSystem('EPSG:31370'),
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        return self.__processing_uitvoeren(instellingen, 'mergevectorlayers')

    def delete_duplicates_by_attribute(self, laag: QgsVectorLayer, kolommen: list = [0]):
        # processing parameters instellen
        instellingen = {
            'INPUT': laag,
            'FIELDS': kolommen,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        return self.__processing_uitvoeren(instellingen, 'removeduplicatesbyattribute')

    def extract_selected_features(self, laag: QgsVectorLayer):
        # processing parameters instellen
        instellingen = {
            'INPUT': laag,
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        return self.__processing_uitvoeren(instellingen, 'saveselectedfeatures')

    def select_by_location(self, laag1: QgsVectorLayer, laag2: QgsVectorLayer, opties: list = [3]) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag1,
            'PREDICATE': opties,
            'INTERSECT': laag2,
            'METHOD': 0
        }

        # processing uitvoeren
        return self.__processing_uitvoeren(instellingen, 'selectbylocation', False, False)

    def join_attributes_by_location(self, laag1: QgsVectorLayer, laag2: QgsVectorLayer, opties: list = [5],
                                    kolommen: list = ['DG','WP','POP']) -> QgsVectorLayer:
        # processing parameters instellen
        instellingen = {
            'INPUT': laag1,
            'PREDICATE': opties,
            'JOIN': laag2,
            'JOIN_FIELDS': kolommen,
            'METHOD': 0,
            'DISCARD_NONMATCHING': True,
            'PREFIX': '',
            'OUTPUT': 'TEMPORARY_OUTPUT'
        }

        # processing uitvoeren
        return self.__processing_uitvoeren(instellingen, 'joinattributesbylocation')

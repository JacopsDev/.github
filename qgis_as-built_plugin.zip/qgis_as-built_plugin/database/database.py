# hulp imports
import pandas
import os
from datetime import date


class Database:
    def __init__(self, database):
        self.database_locatie = f'{os.path.expanduser("~")}/AppData/Roaming/QGIS/QGIS3/profiles/default/python/plugins/asbuilt/database/{database}'
        self.database = pandas.read_csv(self.database_locatie)

    def schrijven(self, data) -> None:
        # variabelen
        datum = data['datum']
        rij = self.positie_in_de_database(datum)
        database_kolommen = list(self.database.keys())

        # data toevoegen aan dataframe
        for kolom in database_kolommen:
            # data invullen indien de kolom in de meegegeven data dictionary zit
            if kolom == 'datum':
                self.database.loc[rij, kolom] = data[kolom]
            # aantallen opslaan als int
            elif kolom in data.keys():
                self.database.loc[rij, kolom] = int(data[kolom])
            # 0 invullen in de database indien de kolom niet in de data dictionary zit
            else:
                self.database.loc[rij, kolom] = 0

        # dataframe wegschrijven naar csv file
        self.database.to_csv(self.database_locatie, index=False)

    def positie_in_de_database(self, datum) -> int:
        # zoeken naar de ingegeven datum in de database
        positie = [index for index, row in self.database.iterrows() if datum == row.iloc[0]]

        # checken of datum in de database staat
        if len(positie) == 0:
            return len(self.database)

        # postitie uit lijst halen
        positie = int(positie[0])

        return positie

    def lezen(self, datum) -> dict:
        # positie bepalen in de database adhv de datum
        positie = self.positie_in_de_database(datum)

        # data voor de ingegeven datum terug geven
        return self.database.loc[positie]

    def vorige_maand_lezen(self):
        # variabelen
        huidige_maand = str(date.today()).split('-')[1]
        positie = 0

        # zoeken naar de ingegeven datum in de database
        for index, row in reversed(list(self.database.iterrows())):
            # variabelen
            maand = row.iloc[0].split('-')[1]
            positie = index

            # zolang de maand gelijk is aan de huidige maand verder gaan
            if maand == huidige_maand:
                continue
            else:
                break

        # data voor de datum voorgaand aan de ingegeven datum terug geven
        return self.database.loc[positie]

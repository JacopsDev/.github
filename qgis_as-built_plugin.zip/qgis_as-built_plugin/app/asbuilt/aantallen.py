# qgis imports
from qgis.core import QgsProject, QgsVectorLayer, QgsFeatureRequest, QgsFeature

# interne imports
from .processing_ import Processing
from .database import Database


class ProjectLagen:
    def __init__(self):
        self._geolantis_lines: QgsVectorLayer = QgsProject.instance().mapLayersByName('Geolantis_Lines')[0]
        self._geolantis_points: QgsVectorLayer = QgsProject.instance().mapLayersByName('Geolantis_Points')[0]
        self._facade: QgsVectorLayer = QgsProject.instance().mapLayersByName('Facade')[0]
        #self._hpp: QgsVectorLayer = QgsProject.instance().mapLayersByName('HPP (local)')[0]
        self._hpp: QgsVectorLayer = QgsProject.instance().mapLayersByName('HPP (WFS)')[0]
        self._straten: QgsVectorLayer = QgsProject.instance().mapLayersByName('Z-GRB — ZA. Straten')[0]
        self._wijkpunten: QgsVectorLayer = QgsProject.instance().mapLayersByName('WIJKZONES')[0]
        self._db_asbuilt_hpp: QgsVectorLayer = QgsProject.instance().mapLayersByName('As-built HPP aantallen')[0]
        self._db_geolantis_lines: QgsVectorLayer = QgsProject.instance().mapLayersByName('Geolantis lines lengtes')[0]
        self._db_hld_trenching: QgsVectorLayer = QgsProject.instance().mapLayersByName('HLD trenching lengtes')[0]


class Trenching(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._geolantis_lines

        self.actuele_lengte: int = 0
        self.vorige_lengte: int = 0  # trenching + crossing
        self.totale_lengte: int = 0  # trenching + crossing

        self.__berekenen()

    def __berekenen(self) -> None:
        """ ACTUELE LENGTE """
        self.__laag = Processing().split_with_lines(self.__laag, self.__zone)
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)

        qry = QgsFeatureRequest().setSubsetOfAttributes([4])

        for trench in self.__laag.getFeatures(qry):
            naam = trench['CategoryName']

            if 'BIS' in naam:
                self.actuele_lengte += trench.geometry().length()

        """ VORIGE LENGTE """
        self.vorige_lengte = Database(self.__zone, 'Geolantis lines lengtes').inlezen()

        """ TOTALE LENGTE """
        self.totale_lengte = Database(self.__zone, 'HLD trenching lengtes').inlezen(True)


class Crossings(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._geolantis_lines

        self.actuele_lengte: int = 0

        self.__berekenen()

    def __berekenen(self) -> None:
        """ ACTUELE LENGTE """
        self.__laag = Processing().split_with_lines(self.__laag, self.__zone)
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)

        qry = QgsFeatureRequest().setSubsetOfAttributes([4])

        for crossing in self.__laag.getFeatures(qry):
            naam = crossing['CategoryName']

            if 'Handboring' in naam or 'Open sleuf oversteek' in naam:
                self.actuele_lengte += crossing.geometry().length()


class Facade(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._facade

        self.lengte: int = 0

        self.__berekenen()

    def __berekenen(self) -> None:
        """ LENGTE """
        self.__laag = Processing().split_with_lines(self.__laag, self.__zone)
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)
        self.__laag = Processing().extract_by_expression(self.__laag, '"uitgevoerd" is true')

        qry = QgsFeatureRequest().setSubsetOfAttributes([])

        for facade in self.__laag.getFeatures(qry):
            self.lengte += facade.geometry().length()


class Manholes(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._geolantis_points

        self.aantal: int = 0

        self.__berekenen()

    def __berekenen(self) -> None:
        """ AANTAL """
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)

        self.aantal = self.__laag.featureCount()


class Asbuilt:
    def __init__(self, zone: QgsVectorLayer):
        self.trenching: Trenching = Trenching(zone)
        self.crossings: Crossings = Crossings(zone)
        self.facade: Facade = Facade(zone)
        self.manholes: Manholes = Manholes(zone)


class AsbuiltHPP(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._hpp

        self.actueel_aantal: int = 0
        self.vorige_aantal: int = 0

        self.__berekenen()

    def __berekenen(self) -> None:
        """ ACTUELE AANTAL """
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)
        self._straten = Processing().extract_by_location(self._straten, self.__zone)
        self._geolantis_lines = Processing().extract_by_location(self._geolantis_lines, self.__zone)
        self._facade = Processing().extract_by_location(self._facade, self.__zone)

        dichtsbijzijnde_straat_lijnen = Processing().shortest_line(self.__laag, self._straten)
        dichtsbijzijnde_straat_lijnen = Processing().delete_duplicates_by_attribute(dichtsbijzijnde_straat_lijnen,
                                                                                    ['DHid'])

        distributie_lijnen = Processing().merge_vector_layers([self._geolantis_lines, self._facade])

        self.actueel_aantal = Processing().extract_by_location(
            dichtsbijzijnde_straat_lijnen, distributie_lijnen, [7]).featureCount()

        """ VORIGE AANTAL """
        self.vorige_aantal = Database(self.__zone, 'As-built HPP aantallen').inlezen()


class BouwstraatHPP(ProjectLagen):
    def __init__(self, zone: QgsVectorLayer):
        super().__init__()

        self.__zone = zone
        self.__laag: QgsVectorLayer = self._hpp

        self.aantal: int = 0
        self.totale_aantal: int = 0

        self.__berekenen()

    def __berekenen(self) -> None:
        """ AANTAL """
        self.__laag = Processing().extract_by_location(self.__laag, self.__zone)

        # CAP adressen negeren
        self.__laag = Processing().extract_by_expression(
            self.__laag,
            '"Targetdelivery" = \'HC\''
        )

        """ TOTALE AANTAL """
        self.totale_aantal = self.__laag.featureCount()

        """ AANTAL """
        self.__laag = Processing().extract_by_expression(
            self.__laag,
            'to_string("HPPlasticCompleted") IS NOT \'None\''
        )

        self.aantal = self.__laag.featureCount()


class HPP:
    def __init__(self, zone: QgsVectorLayer):
        self.asbuilt_hpp: AsbuiltHPP = AsbuiltHPP(zone)
        self.bouwstraat_hpp: BouwstraatHPP = BouwstraatHPP(zone)


class Zone(ProjectLagen):
    def __init__(self, zone: tuple):
        super().__init__()

        self.naam = zone[0] + ' ' + zone[1]
        self.__laag: QgsVectorLayer = Processing().extract_by_expression(
            self._wijkpunten,
            f'"DG" = \'{zone[0]}\' and "WP" = \'{zone[1]}\''
        )

        self.asbuilt: Asbuilt = Asbuilt(self.__laag)
        self.hpp: HPP = HPP(self.__laag)

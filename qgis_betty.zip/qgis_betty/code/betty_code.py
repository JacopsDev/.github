from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
import processing


class UnitMeetpunten(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer('exportwa', 'Export WA', types=[QgsProcessing.TypeVector], defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(8, model_feedback)
        results = {}
        outputs = {}

        # Geselecteerde objecten uitnemen
        alg_params = {
            'INPUT': 'WIJKPUNTEN_a0b3d0fb_468f_4104_9931_f0464d1104b4',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['GeselecteerdeObjectenUitnemen'] = processing.run('native:saveselectedfeatures', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Clippen
        alg_params = {
            'INPUT': 'HC_6086e5a3_8309_47ea_8b15_92c9bb9833b1',
            'OVERLAY': outputs['GeselecteerdeObjectenUitnemen']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Clippen'] = processing.run('native:clip', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Attributen koppelen op veldwaarde
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'UTAC',
            'FIELDS_TO_COPY': [''],
            'FIELD_2': 'UTAC',
            'INPUT': outputs['Clippen']['OUTPUT'],
            'INPUT_2': parameters['exportwa'],
            'METHOD': 1,  # Take attributes of the first matching feature only (one-to-one)
            'PREFIX': 'NEW',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AttributenKoppelenOpVeldwaarde'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Attributen koppelen op veldwaarde2
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'UTAC',
            'FIELDS_TO_COPY': ['HHLabel','AppeeeLassenStatus'],
            'FIELD_2': 'UTAC',
            'INPUT': outputs['AttributenKoppelenOpVeldwaarde']['OUTPUT'],
            'INPUT_2': 'UnitsProgressTracker_DG027_c312e9ea_1f27_4620_932a_5135227114ec',
            'METHOD': 1,  # Take attributes of the first matching feature only (one-to-one)
            'PREFIX': 'UPT',
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['AttributenKoppelenOpVeldwaarde2'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Veld calculator
        alg_params = {
            'FIELD_LENGTH': 0,
            'FIELD_NAME': 'MHCHECK',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 0,  # Decimal (double)
            'FORMULA': 'if("HH_handle"="NEWHH handle ID",1,0)',
            'INPUT': outputs['AttributenKoppelenOpVeldwaarde2']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['VeldCalculator'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Veld calculator
        alg_params = {
            'FIELD_LENGTH': 0,
            'FIELD_NAME': 'POPCHECK',
            'FIELD_PRECISION': 0,
            'FIELD_TYPE': 0,  # Decimal (double)
            'FORMULA': 'if("NEWPOP lade" > 9, \r\n\t\r\n\tconcat("Tray1v", "Position1v") = concat("NEWPOP lade","NEWPOP positie"), concat("Tray1v", "Position1v") = concat(\'0\',"NEWPOP lade","NEWPOP positie")\r\n\t\r\n\t)\r\n',
            'INPUT': outputs['VeldCalculator']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['VeldCalculator'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Stijl voor de laag instellen
        alg_params = {
            'INPUT': outputs['VeldCalculator']['OUTPUT'],
            'STYLE': 'C:\\Users\\casperdemeersseman\\JACOPS NV\\F4F 27 Detailed Design - Documenten\\Dossier\\027.05 - DG027\\00 - BETTY\\BETTY\\MEETPUNTEN.qml'
        }
        outputs['StijlVoorDeLaagInstellen'] = processing.run('native:setlayerstyle', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Laag in project laden
        alg_params = {
            'INPUT': outputs['StijlVoorDeLaagInstellen']['OUTPUT'],
            'NAME': 'MEETPUNTEN'
        }
        outputs['LaagInProjectLaden'] = processing.run('native:loadlayer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        return results

    def name(self):
        return 'UNIT MEETPUNTEN'

    def displayName(self):
        return 'UNIT MEETPUNTEN'

    def group(self):
        return ''

    def groupId(self):
        return ''

    def createInstance(self):
        return UnitMeetpunten()

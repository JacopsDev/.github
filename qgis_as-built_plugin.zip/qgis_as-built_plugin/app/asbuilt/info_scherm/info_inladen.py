# interne imports
from ..aantallen import Zone, ProjectLagen

# qgis imports
from qgis.core import QgsProject


class AsbuiltInfo(ProjectLagen):
    def __init__(self):
        super().__init__()
        self.__foutieve_selectie: bool = False
        self.zone = self.__geselecteerde_zone()

        self.zone_naam: str = ''
        self.trenching: int = 0
        self.crossings: int = 0
        self.facade: int = 0
        self.manholes: int = 0
        self.hpp: int = 0
        self.bouwstraatHPP: int = 0

        if self.__foutieve_selectie:
            return

        self.__berekenen()

    def __berekenen(self):
        zone = Zone(self.zone)

        self.zone_naam = str(zone.naam)
        self.trenching = self.__groot_getal_leesbaar_maken(str(int(zone.asbuilt.trenching.actuele_lengte))) + ' m'
        self.crossings = self.__groot_getal_leesbaar_maken(str(int(zone.asbuilt.crossings.actuele_lengte))) + ' m'
        self.facade = self.__groot_getal_leesbaar_maken(str(int(zone.asbuilt.facade.lengte))) + ' m'
        self.manholes = str(zone.asbuilt.manholes.aantal)
        self.hpp = self.__groot_getal_leesbaar_maken(str(zone.hpp.asbuilt_hpp.actueel_aantal))
        self.bouwstraatHPP = self.__groot_getal_leesbaar_maken(str(zone.hpp.bouwstraat_hpp.aantal))

    def __geselecteerde_zone(self) -> tuple:
        geselecteerde_features = self._wijkpunten.selectedFeatures()

        if len(geselecteerde_features) == 0:
            self.__foutieve_selectie = True
            return ()

        try:
            zone = (geselecteerde_features[0]['DG'], geselecteerde_features[0]['WP'])
        except IndexError:
            self.__foutieve_selectie = True
            zone = ()

        return zone

    def __groot_getal_leesbaar_maken(self, getal: str) -> str:
        aantal_te_plaatsen_scheidingen = len(getal) // 3

        if len(getal) < 4:
            return getal

        aantal_geplaatste_scheidingen = 0
        for punt in range(aantal_te_plaatsen_scheidingen):
            scheidingsteken_positie = punt + 1
            scheidingsteken_positie = scheidingsteken_positie * 3
            scheidingsteken_positie = scheidingsteken_positie + aantal_geplaatste_scheidingen

            getal = self.__scheiding_toevoegen(getal, scheidingsteken_positie, ' ')
            aantal_geplaatste_scheidingen += 1

        return getal

    @staticmethod
    def __scheiding_toevoegen(getal: str, positie: int, scheidingsteken: str):
        return f'{getal[:-positie]}{scheidingsteken}{getal[-positie:]}'

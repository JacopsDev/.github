# qt imports
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QToolBar


# interne imports
from .asbuilt_dockwidget import AsbuiltDockWidget
from .resources import *  # Initialize Qt resources from file resources.py

# hulp imports
import os.path


class Asbuilt:
    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface

        # jacops toolbar
        self.jacops_toolbar = self.__jacops_toolbar()

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Asbuilt_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Asbuilt')
        self.pluginIsActive = False
        self.dockwidget = None

    def __jacops_toolbar(self) -> QToolBar:
        # toolbar variabele
        naam = 'Jacops Toolbar'
        toolbar = self.iface.mainWindow().findChild(QToolBar, naam)

        # kijken of de toolbar al bestaat
        if toolbar is None:
            # toolbar toevoegen
            toolbar = self.iface.addToolBar(naam)
            # toolbar naam instellen
            toolbar.setObjectName(naam)
            return toolbar
        else:
            # variabele gelijkstellen aan bestaande toolbar
            return self.iface.mainWindow().findChild(QToolBar, naam)

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('Asbuilt', message)

    def add_action(
            self,
            icon_path,
            text,
            callback,
            enabled_flag=True,
            add_to_menu=False,
            add_to_toolbar=True,
            status_tip=None,
            whats_this=None,
            parent=None):

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            #self.iface.addToolBarIcon(action)
            self.jacops_toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        icon_path = ':/plugins/asbuilt/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'Asbuilt'),
            callback=self.run,
            parent=self.iface.mainWindow())

    # --------------------------------------------------------------------------

    def onClosePlugin(self):
        # disconnects
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)
        self.pluginIsActive = False

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Asbuilt'),
                action)
            #self.iface.removeToolBarIcon(action)
            self.jacops_toolbar.removeAction(action)

            # --------------------------------------------------------------------------

    def run(self):
        if not self.pluginIsActive:
            self.pluginIsActive = True

            # dockwidget may not exist if:
            #    first run of plugin
            #    removed on close (see self.onClosePlugin method)
            if self.dockwidget is None:
                # Create the dockwidget (after translation) and keep reference
                self.dockwidget = AsbuiltDockWidget()

            # connect to provide cleanup on closing of dockwidget
            self.dockwidget.closingPlugin.connect(self.onClosePlugin)

            # show the dockwidget
            self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
            self.dockwidget.show()

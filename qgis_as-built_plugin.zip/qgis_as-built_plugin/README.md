# ALGEMENE PLUGIN VOOR ALLE AUTOMATISATIE IVM AS-BUILT

## Zone info
Na selectie van een zone in de laag WIJKZONES kan de basis as-built informatie van die zone berekend en gevisualiseerd worden, door op de knop te klikken.
## Progressie
Na selectie van een zone in de laag WIJKZONES wordt de trenching en HPP progressie van de geselecteerde zone berekend en gevisualiseerd via grafieken.
## Geolantis lines snippet maken
Berekend voor alle zones de as-built HPP aantallen en trenching + crossing aantallen.
Schrijft deze info weg naar respectievelijk As-built HPP aantallen en Geolantis lines lengtes.
## Rapport
Berekend onderstaande as-built info voor alle zones en schrijft deze weg naar een EXCEL file op de locatie van het qgis project.
### Trenching (m)
Aantal opgemeten meters trenching in Geolantis.
### Trenching (%)
Aantal opgemeten meters trenching in Geolantis tegenover het totaal aantal trenching uit de HLD BOM.
### ΔTrenching (m)
Aantal opgemeten meters trenching in Geolantis van deze maand tegenover het aantal opgemeten meters trenching in Geolantis van vorige maand.
### Façade (m)
Aantal opgemeten meters façade in Geostruct.
### HPP (units)
Aantal units met opgemeten trenching of façade.
### HPP (%)
Aantal units met opgemeten trenching of façade tegenover het totaal aantal units in bouwstraat.
### ΔHPP (units)
Aantal units met opgemeten trenching of façade van deze maand tegenover het aantal units waar opgemeten trenching of façade ligt van vorige maand.
### ΔHPP bouwstraat (units)
Aantal units met opgemeten trenching of façade tegenover het aantal units die aangegeven staan als HPP in bouwstraat.
Een negatief cijfer betekend dat er meer units in bouwstraat HPP staan dan er units opgemeten as-built hebben.
### ΔHPP bouwstraat (%)
Aantal units met opgemeten trenching of façade tegenover het aantal units die aangegeven staan als HPP in bouwstraat.
100% betekend dat alle units die HPP staan in bouwstraat opgemeten trenching of façade hebben.
## *Cyient export - TODO*
## *HPP's afmelden - TODO*

# module installeren indien deze niet aanwezig is
try:
    import openpyxl
except ModuleNotFoundError:
    from ...import_fix import OngekendeModule

    OngekendeModule('openpyxl').installeren()
    quit()

# qgis import
from qgis.core import QgsProject, QgsVectorLayer, QgsTask, QgsFeatureRequest

# interne imports
from ..aantallen import ProjectLagen, Zone


class Rapport(QgsTask, ProjectLagen):
    def __init__(self, btn_rapport, description: str):
        super().__init__(description, QgsTask.CanCancel)

        self.__zones: dict = {}

        self.__btn_rapport = btn_rapport
        self.__btn_rapport_text: str = self.__btn_rapport.text()

        self.__locatie = None
        self.__workbook = None
        self.__worksheet = None

    def run(self):
        self.__btn_rapport.setEnabled(False)

        self.__berekening()

        self.__rapport_inladen()

        self.__rapport_vullen()

        self.__workbook.save(self.__locatie)

        return True

    def finished(self, result):
        self.__btn_rapport.setText(self.__btn_rapport_text)
        self.__btn_rapport.setEnabled(True)

    def __berekening(self):
        dg = self._wijkpunten.fields().indexFromName('DG')
        wp = self._wijkpunten.fields().indexFromName('WP')
        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([dg, wp])

        huidig_wijkpunt = 0
        totaal_aantal_wijkpunten = self._wijkpunten.featureCount()

        for zone in self._wijkpunten.getFeatures(qry):
            huidig_wijkpunt += 1
            self.__btn_rapport.setText(f'{huidig_wijkpunt} / {totaal_aantal_wijkpunten}')

            zone = Zone((zone['DG'], zone['WP']))

            self.__zones[zone.naam] = zone

    def __rapport_inladen(self) -> None:
        # locatie van rapport excel
        self.__locatie = QgsProject.instance().readPath("./ASBUILT_RAPPORT.xlsx")

        # rapport excel inladen met openpyxl
        self.__workbook = openpyxl.load_workbook(self.__locatie)

        # actieve sheet uit excel nemen
        self.__worksheet = self.__workbook.active

    def __rapport_vullen(self) -> None:
        totalen = list(range(6, 8))
        deelgebieden = list(range(12, 21))
        wijkpunten = list(range(25, 83))

        # --- DG010 - DG013 - DG020 - DG027 - DG033 --- #
        aantallen = self.__aantallen_samenvoegen('DG010', 'DG013', 'DG020', 'DG027', 'DG033')

        self.__rij_invullen(
            6,
            int(aantallen[0]),
            self.__percentage(aantallen[0], aantallen[1]),
            self.__delta(aantallen[0], aantallen[2]),
            int(aantallen[3]),
            aantallen[4],
            self.__percentage(aantallen[4], aantallen[6]),
            self.__delta(aantallen[4], aantallen[5]),
            self.__delta(aantallen[4], aantallen[7]),
            self.__percentage(aantallen[4], aantallen[7])
        )

        # --- TOTAAL --- #
        aantallen = self.__aantallen_samenvoegen(' ')

        self.__rij_invullen(
            7,
            int(aantallen[0]),
            self.__percentage(aantallen[0], aantallen[1]),
            self.__delta(aantallen[0], aantallen[2]),
            int(aantallen[3]),
            aantallen[4],
            self.__percentage(aantallen[4], aantallen[6]),
            self.__delta(aantallen[4], aantallen[5]),
            self.__delta(aantallen[4], aantallen[7]),
            self.__percentage(aantallen[4], aantallen[7])
        )

        # --- DEELGEBIEDEN --- #
        for rij in deelgebieden:
            zone = self.__worksheet.cell(row=rij, column=1).value

            aantallen = self.__aantallen_samenvoegen(zone)

            self.__rij_invullen(
                rij,
                int(aantallen[0]),
                self.__percentage(aantallen[0], aantallen[1]),
                self.__delta(aantallen[0], aantallen[2]),
                int(aantallen[3]),
                aantallen[4],
                self.__percentage(aantallen[4], aantallen[6]),
                self.__delta(aantallen[4], aantallen[5]),
                self.__delta(aantallen[4], aantallen[7]),
                self.__percentage(aantallen[4], aantallen[7])
            )

        # --- WIJKPUNTEN --- #
        for rij in wijkpunten:
            zone = self.__worksheet.cell(row=rij, column=1).value
            zone = zone.split(' - ')[0]

            if zone not in self.__zones.keys():
                continue

            trenching_en_crossing = (self.__zones[zone].asbuilt.trenching.actuele_lengte +
                                     self.__zones[zone].asbuilt.crossings.actuele_lengte)

            self.__rij_invullen(
                rij,
                int(trenching_en_crossing),
                self.__percentage(trenching_en_crossing, self.__zones[zone].asbuilt.trenching.totale_lengte),
                self.__delta(trenching_en_crossing, self.__zones[zone].asbuilt.trenching.vorige_lengte),
                int(self.__zones[zone].asbuilt.facade.lengte),
                self.__zones[zone].hpp.asbuilt_hpp.actueel_aantal,
                self.__percentage(self.__zones[zone].hpp.asbuilt_hpp.actueel_aantal,
                                  self.__zones[zone].hpp.bouwstraat_hpp.totale_aantal),
                self.__delta(self.__zones[zone].hpp.asbuilt_hpp.actueel_aantal,
                             self.__zones[zone].hpp.asbuilt_hpp.vorige_aantal),
                self.__delta(self.__zones[zone].hpp.asbuilt_hpp.actueel_aantal,
                             self.__zones[zone].hpp.bouwstraat_hpp.aantal),
                self.__percentage(self.__zones[zone].hpp.asbuilt_hpp.actueel_aantal,
                                  self.__zones[zone].hpp.bouwstraat_hpp.aantal)
            )

    def __aantallen_samenvoegen(self, *args) -> list:
        aantallen = [0, 0, 0, 0, 0, 0, 0, 0]

        for wijkpunt, zone in self.__zones.items():

            for deelgebied in args:

                if deelgebied in wijkpunt:
                    aantallen[0] += zone.asbuilt.trenching.actuele_lengte + zone.asbuilt.crossings.actuele_lengte
                    aantallen[1] += zone.asbuilt.trenching.totale_lengte
                    aantallen[2] += zone.asbuilt.trenching.vorige_lengte
                    aantallen[3] += zone.asbuilt.facade.lengte
                    aantallen[4] += zone.hpp.asbuilt_hpp.actueel_aantal
                    aantallen[5] += zone.hpp.asbuilt_hpp.vorige_aantal
                    aantallen[6] += zone.hpp.bouwstraat_hpp.totale_aantal
                    aantallen[7] += zone.hpp.bouwstraat_hpp.aantal

        return aantallen

    def __rij_invullen(self, rij, *args) -> None:
        kolom = 2

        for waarde in args:
            self.__worksheet.cell(row=rij, column=kolom, value=waarde)

            kolom += 1

    @staticmethod
    def __percentage(waarde1, waarde2) -> int:
        # waardes omzetten in integers
        waarde1 = int(waarde1)
        waarde2 = int(waarde2)

        # fix voor delen door 0
        if waarde2 == 0:
            return 100

        # percentage berekenen
        percentage = waarde1 / waarde2
        percentage = percentage * 100
        percentage = int(percentage)

        # indien het percentage hoger is als 100 afronden naar 100
        if percentage > 100:
            percentage = 100

        return percentage

    @staticmethod
    def __delta(waarde1, waarde2) -> int:
        # waardes omzetten in integers
        waarde1 = int(waarde1)
        waarde2 = int(waarde2)

        # delta berekenen
        delta = waarde1 - waarde2

        """
        # indien de delta kleiner is als 0 afronden naar 0
        if delta < 0:
            delta = 0
        """

        return delta

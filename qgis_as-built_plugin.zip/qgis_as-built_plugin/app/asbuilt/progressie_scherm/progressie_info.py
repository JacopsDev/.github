# hulp imports
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

# qgis imports
from qgis.core import QgsApplication, Qgis, QgsProject, QgsVectorLayer
from qgis.utils import iface

# interne imports
from ..database import Database
from ..aantallen import BouwstraatHPP, ProjectLagen
from ..processing_ import Processing


class Progressie(ProjectLagen):
    def __init__(self):
        super().__init__()
        self.__foutieve_selectie: bool = False
        self.__zone = self.__geselecteerde_zone()

        self.maanden: tuple = ()
        self.hpp: dict = {}
        self.trenching: dict = {}
        self.bouwstraat: dict = {}
        self.geolantis_lines: dict = {}

        if self.__foutieve_selectie:
            iface.messageBar().pushMessage("Error", "Ongeldige selectie", level=Qgis.Warning)
            return

        self.__berekenen()

    def __berekenen(self) -> None:
        asbuilt_hpp_aantallen = Database(self.__zone, 'As-built HPP aantallen').inlezen_per_datum()
        bouwstraat_hpp_aantal = BouwstraatHPP(self.__zone)
        self.geolantis_lines = Database(self.__zone, 'Geolantis lines lengtes').inlezen_per_datum()
        hld_trenching_lengte = Database(self.__zone, 'HLD trenching lengtes')

        hpp_totaal = bouwstraat_hpp_aantal.totale_aantal
        trenching_totaal = hld_trenching_lengte.inlezen(True)

        self.maanden = tuple(asbuilt_hpp_aantallen.keys())
        self.hpp = self.__percentages(asbuilt_hpp_aantallen, hpp_totaal)
        self.trenching = self.__percentages(self.geolantis_lines, trenching_totaal)
        self.bouwstraat = self.__percentages(asbuilt_hpp_aantallen, bouwstraat_hpp_aantal.aantal)

    @staticmethod
    def __percentages(aantallen: dict, totaal: int) -> tuple:
        percentages = ()

        for aantal in aantallen.values():
            percentage = aantal / totaal
            percentage = percentage * 100
            percentage = round(percentage, 0)
            percentage = int(percentage)

            if percentage > 100:
                percentage = 100

            if percentage < 0:
                percentage = 0

            percentage = (percentage,)

            percentages += percentage

        return percentages

    def __geselecteerde_zone(self) -> QgsVectorLayer:
        geselecteerde_features = self._wijkpunten.selectedFeatures()

        if len(geselecteerde_features) == 0:
            self.__foutieve_selectie = True
            return

        try:
            zone = (geselecteerde_features[0]['DG'], geselecteerde_features[0]['WP'])
        except IndexError:
            self.__foutieve_selectie = True
            return
        else:
            return Processing().extract_by_expression(
                self._wijkpunten,
                f'"DG" = \'{zone[0]}\' and "WP" = \'{zone[1]}\''
            )


class ProgressiePlot:
    def __init__(self):
        self.__progressie_data: Progressie = Progressie()

    def tonen(self):
        maanden = self.__progressie_data.maanden
        data = {
            'As-built HPP / totaal': self.__progressie_data.hpp,
            'As-built HPP / bouwstraat': self.__progressie_data.bouwstraat,
            'Trenching / totaal': self.__progressie_data.trenching
        }

        x = np.arange(len(maanden))  # the label locations
        width = 0.25  # the width of the bars
        multiplier = 0

        # toolbar aan of uit
        #mpl.rcParams['toolbar'] = 'None'
        mpl.rcParams['toolbar'] = 'toolbar2'

        fig, axs = plt.subplots(2, 1, figsize=(7, 9), layout='tight')

        for attribute, measurement in data.items():
            offset = width * multiplier
            rects = axs[0].bar(x + offset, measurement, width, label=attribute)
            axs[0].bar_label(rects, padding=3)
            multiplier += 1

        axs[0].set_ylabel('Percentage')
        axs[0].set_xticks(x + width, maanden)
        axs[0].set_title('Percentages')
        axs[0].legend(loc='upper left')

        axs[1].plot(
            list(self.__progressie_data.geolantis_lines.keys()),
            list(self.__progressie_data.geolantis_lines.values())
        )

        for xi, yi, text in (zip(
                list(self.__progressie_data.geolantis_lines.keys()),
                list(self.__progressie_data.geolantis_lines.values()),
                list(self.__progressie_data.geolantis_lines.values()))):
            axs[1].annotate(text, xy=(xi, yi), xycoords='data', xytext=(-15, 2), textcoords='offset points')

        axs[1].set_ylabel('Lengte (m)')
        axs[1].set_title('Trenching')

        # ZOOM INSTELLEN #
        axs[0].set_xlim(left=self.__zoom_niveau())
        axs[0].set_ylim(0, 139)
        axs[1].set_xlim(left=self.__zoom_niveau())
        axs[1].set_ylim(bottom=0, top=self.__top_marge())

        plt.show()

    def __zoom_niveau(self) -> float:
        data_blok_breedte = 1
        aantal_data_blokken = len(self.__progressie_data.hpp)
        te_tonen_data_blokken = 4

        te_verbergen_data = aantal_data_blokken - te_tonen_data_blokken

        zoom = -0.25
        for i in range(te_verbergen_data):
            zoom += data_blok_breedte

        return zoom

    def __top_marge(self) -> int:
        data = list(self.__progressie_data.geolantis_lines.values())
        data.sort()

        hoogste_getal = data[-1]
        marge = 1.1

        top_marge = hoogste_getal * marge
        top_marge = int(top_marge)

        return top_marge

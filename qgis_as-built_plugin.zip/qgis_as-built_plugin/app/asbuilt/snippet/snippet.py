# interne imports
from ..aantallen import ProjectLagen, Zone
from ..database import Database

# qgis imports
from qgis.core import QgsVectorLayer, QgsFeatureRequest, QgsTask, Qgis

# qt imports
from qgis.PyQt.QtCore import QDate


class Snippet(QgsTask, ProjectLagen):
    def __init__(self, btnGeolantisLinesSnippet, description: str):

        super().__init__(description, QgsTask.CanCancel)

        self.__trenching: list = []
        self.__hpp: list = []

        self.__btnGeolantisLinesSnippet = btnGeolantisLinesSnippet
        self.__btn_text = self.__btnGeolantisLinesSnippet.text()

    def run(self):
        self.__btnGeolantisLinesSnippet.setEnabled(False)

        self.__berekening()
        Database(None, 'Geolantis lines lengtes').wegschrijven(self.__trenching)
        Database(None, 'As-built HPP aantallen').wegschrijven(self.__hpp)

        return True

    def finished(self, result):
        self.__btnGeolantisLinesSnippet.setText(self.__btn_text)
        self.__btnGeolantisLinesSnippet.setEnabled(True)

    def __berekening(self):
        self.__id_toevoegen()

        self.__datum_toevoegen()
        
        self.__aantallen_toevoegen()

    def __datum_toevoegen(self):
        vandaag = QDate.currentDate()

        self.__trenching.append(vandaag)
        self.__hpp.append(vandaag)

    def __id_toevoegen(self):
        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([])

        laatste_trenching_id = [feature.id() for feature in self._db_geolantis_lines.getFeatures(qry)][-1]
        laatste_hpp_id = [feature.id() for feature in self._db_asbuilt_hpp.getFeatures(qry)][-1]

        self.__trenching.append(laatste_trenching_id + 1)
        self.__hpp.append(laatste_hpp_id + 1)

    def __aantallen_toevoegen(self):
        dg = self._wijkpunten.fields().indexFromName('DG')
        wp = self._wijkpunten.fields().indexFromName('WP')
        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([dg, wp])

        trenching = {}
        hpp = {}
        huidig_wijkpunt = 0
        totaal_aantal_wijkpunten = self._wijkpunten.featureCount()
        for zone in self._wijkpunten.getFeatures(qry):
            huidig_wijkpunt += 1
            self.__btnGeolantisLinesSnippet.setText(f'{huidig_wijkpunt} / {totaal_aantal_wijkpunten}')
            zone = Zone((zone['DG'], zone['WP']))

            trenching[zone.naam] = int(zone.asbuilt.trenching.actuele_lengte + zone.asbuilt.crossings.actuele_lengte)
            hpp[zone.naam] = zone.hpp.asbuilt_hpp.actueel_aantal

        trenching = dict(sorted(trenching.items()))
        hpp = dict(sorted(hpp.items()))

        self.__trenching += list(trenching.values())
        self.__hpp += list(hpp.values())

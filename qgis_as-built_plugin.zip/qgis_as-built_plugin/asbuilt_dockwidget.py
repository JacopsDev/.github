# qt imports
from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import pyqtSignal

# qgis imports
from qgis.utils import iface
from qgis.core import QgsApplication

# hulp imports
import os

# interne imports
from .app.asbuilt.rapport.rapport import Rapport
from .app.asbuilt.export import CyientExport
from .app.asbuilt.info_scherm.asbuilt_info import GUI_AsbuiltInfo
from .app.asbuilt.progressie_scherm.progressie_info import ProgressiePlot
from .app.asbuilt.snippet.snippet import Snippet
from .app.hpp.nieuwe_hpps.hpp import GUI_HPPsAfmelden

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'asbuilt_dockwidget_base.ui'))


class AsbuiltDockWidget(QtWidgets.QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent=None):
        super(AsbuiltDockWidget, self).__init__(parent)
        self.setupUi(self)

        # knoppen linken aan acties
        self.btn_asbuilt_info_tonen.clicked.connect(self.asbuilt_info_tonen)
        self.btn_rapport.clicked.connect(self.rapport)
        self.btn_hpps_zonder_asbuilt.clicked.connect(self.hpps_zonder_asbuilt)
        self.btnCyientExport.clicked.connect(self.cyient_export)
        self.btn_hpp_status_bepalen.clicked.connect(self.hpp_status_bepalen)
        self.btnProgressie.clicked.connect(self.progressie_tonen)
        self.btnGeolantisLinesSnippet.clicked.connect(self.geolantis_lines_snippet)
        self.btnHPPsAfmelden.clicked.connect(self.hpps_afmelden)

        # asbuilt info gui object
        self.gui_asbuilt_info = GUI_AsbuiltInfo(iface.mainWindow())

        # hpp afmelden gui object
        self.gui_hpps_afmelden = GUI_HPPsAfmelden(iface.mainWindow())

        # task manager object aanmaken
        self.taken = QgsApplication.taskManager()

    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

    def asbuilt_info_tonen(self):
        self.gui_asbuilt_info.show()

    @staticmethod
    def progressie_tonen():
        ProgressiePlot().tonen()

    def geolantis_lines_snippet(self):
        snippet = Snippet(
            self.btnGeolantisLinesSnippet,
            'geolantis lines snippet'
        )

        self.taken.addTask(snippet)

    def rapport(self):
        rapport = Rapport(
            self.btn_rapport,
            'rapport maken'
        )

        self.taken.addTask(rapport)

    def hpps_afmelden(self):
        self.gui_hpps_afmelden.resize(250, 200)
        self.gui_hpps_afmelden.show()

    @staticmethod
    def hpps_zonder_asbuilt():
        pass

    def cyient_export(self):
        export = CyientExport(
            self,
            'shapefiles export'
        )

        self.taken.addTask(export)

    @staticmethod
    def hpp_status_bepalen():
        pass

# qgis imports
from qgis.core import QgsProject, QgsVectorFileWriter, QgsTask, QgsFeatureRequest

# qt import
from qgis.PyQt.QtCore import QDate

# hulp imports
from datetime import date
import re
import os

# interne imports
from .processing_ import Processing
from .aantallen import ProjectLagen


class CyientExport(QgsTask, ProjectLagen, Processing):
    def __init__(self, gui, description):
        super().__init__(description, QgsTask.CanCancel)

        self.__gui = gui

        self.__btn_text = self.__gui.btnCyientExport.text()

        self.__te_exporteren_lagen = []
        self.__export_locatie = ''

    def run(self):
        """ GUI """
        self.__knoppen_uitschakelen()

        """ BEREKENING """
        # export object aanmaken
        export = ExportLaag(self.__gui)

        # mappen aanmaken
        locatie_qgis_project = QgsProject.instance().readPath(".")
        vandaag = QDate.currentDate().toString("yyyy-MM-dd")

        self.__export_locatie = locatie_qgis_project.split('/')
        self.__export_locatie = self.__export_locatie[:-2]
        self.__export_locatie = '/'.join(self.__export_locatie)

        self.__export_locatie = os.path.join(self.__export_locatie, '05 - SUBCONTRACTORS', 'AS-BUILT', vandaag)

        self.__mappenstructuur_aanmaken(export.zones())

        # layers exporteren
        self.__exporteer(export.facade, 'AccessNet_Facade')
        self.__exporteer(export.crossing, 'Drilling')
        self.__exporteer(export.trenching, 'AccessNet')
        self.__exporteer(export.manhole, 'Accesspoint')

        return True

    def finished(self, result):
        self.__knoppen_inschakelen()

    def __knoppen_uitschakelen(self):
        self.__gui.btnCyientExport.setEnabled(False)
        self.__gui.btnCyientExport.setText('Bliep Bloep Bliep ...')

    def __knoppen_inschakelen(self):
        self.__gui.btnCyientExport.setEnabled(True)
        self.__gui.btnCyientExport.setText(self.__btn_text)

    def __exporteer(self, asbuilt_lagen: dict, naam: str):
        # loopen door asbuilt lagen
        for zone, laag in asbuilt_lagen.items():
            # locatie van de export instellen
            shapefile_naam = f'{zone} - {naam}.shp'
            locatie = os.path.join(self.__export_locatie, self.__wp_map(zone), shapefile_naam)

            # asbuilt laag opslaan naar een shapefile
            QgsVectorFileWriter.writeAsVectorFormat(laag, locatie, 'utf-8', laag.crs(), driverName='ESRI Shapefile')

    @staticmethod
    def __wp_map(zone) -> str:
        # regex
        path = re.findall('(DG\d{3}) (WP\d{2}) - ([A-Z]+-\d{2})', zone)[0]

        return f'{path[0]}/{path[1]} - {path[2]}'

    def __mappenstructuur_aanmaken(self, zones: list) -> None:
        # export map aanmaken
        self.__map_aanmaken(self.__export_locatie)

        # structuur opsplitsen in afzonderlijke mappen
        export_locatie = self.__export_locatie.split('/')

        for zone in zones:
            zone = self.__wp_map(zone).split('/')
            zone = export_locatie + zone

            # door de mappen loopen
            for folder_deel in range(len(export_locatie), len(zone)):
                # per loop een map dieper in de structuur gaan
                folder = zone[:folder_deel + 1]

                # alles weer samenvoegen tot een volwaardig path
                folder = '/'.join(folder)

                self.__map_aanmaken(folder)

    @staticmethod
    def __map_aanmaken(path):
        # checken of map al bestaat
        if os.path.exists(path):
            return

        # map aanmaken
        os.mkdir(path)


class ExportLaag(ProjectLagen):
    def __init__(self, gui):
        super().__init__()

        self.facade = AsbuiltLaag(self._facade, gui, enkel_uitgevoerde_stukken=True).features_per_wp
        self.crossing = AsbuiltLaag(self._geolantis_lines, gui, crossing=True).features_per_wp
        self.trenching = AsbuiltLaag(self._geolantis_lines, gui, trenching=True).features_per_wp
        self.manhole = AsbuiltLaag(self._geolantis_points, gui, manhole=True).features_per_wp

    def zones(self) -> list:
        zones = (list(self.facade.keys()) + list(self.crossing.keys())
                 + list(self.trenching.keys()) + list(self.manhole.keys()))
        return list(dict.fromkeys(zones).keys())


class AsbuiltLaag(ProjectLagen, Processing):
    def __init__(self, laag, gui, enkel_uitgevoerde_stukken: bool = False, crossing: bool = False, trenching: bool = False,
                 manhole: bool = False):
        super().__init__()

        self.__laag = laag
        self.__gui = gui
        self.__enkel_uitgevoerde_stukken = enkel_uitgevoerde_stukken
        self.__crossing = crossing
        self.__trenching = trenching
        self.__manhole = manhole

        self.features_per_wp = {}
        self.__features_verdelen_per_wp()

    def __type_export(self) -> str:
        if self.__manhole:
            return 'Export type: 4/4 | Manholes | zone: '
        if self.__crossing:
            return 'Export type: 2/4 | Crossings | zone: '
        if self.__trenching:
            return 'Export type: 3/4 | Trenching | zone: '
        else:
            return 'Export type: 1/4 | Facade | zone: '

    def __features_verdelen_per_wp(self):
        if self.__manhole is False:
            self.__laag = self.split_with_lines(self.__laag, self._wijkpunten)

        self.__laag = self.join_attributes_by_location(self.__laag, self._wijkpunten)

        if self.__enkel_uitgevoerde_stukken:
            self.__laag = self.extract_by_expression(self.__laag, '"uitgevoerd" is true')

        if self.__crossing:
            filter_expressie = ('"CategoryName" = \'FK_LINE_Handboring\' OR '
                                '"CategoryName" = \'FK_LINE_Open sleuf oversteek\' OR '
                                '"CategoryName" = \'FK_LINE_SYNERGIE_Handboring\' OR '
                                '"CategoryName" = \'FK_LINE_SYNERGIE_Open sleuf oversteek\'')
            self.__laag = self.extract_by_expression(self.__laag, filter_expressie)

        if self.__trenching:
            filter_expressie = '"CategoryName" = \'FK_LINE_BIS\' OR "CategoryName" = \'FK_LINE_SYNERGIE_BIS\''
            self.__laag = self.extract_by_expression(self.__laag, filter_expressie)

        dg = self._wijkpunten.fields().indexFromName('DG')
        wp = self._wijkpunten.fields().indexFromName('WP')
        pop = self._wijkpunten.fields().indexFromName('POP')

        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([dg, wp, pop])

        wijkpunten = [Wijkpunt(wijkpunt) for wijkpunt in self._wijkpunten.getFeatures(qry)]

        i = 0
        aantal_wijkpunten = len(wijkpunten)

        for wijkpunt in wijkpunten:
            i += 1
            self.__status_update(f'{self.__type_export()}{i}/{aantal_wijkpunten}')

            naam = f'{wijkpunt.dg} {wijkpunt.wp} - {wijkpunt.pop}'
            filter_expressie = f'"DG" = \'{wijkpunt.dg}\' AND "WP" = \'{wijkpunt.wp}\' AND "POP" = \'{wijkpunt.pop}\''
            laag = self.extract_by_expression(self.__laag, filter_expressie)
            laag.setName(naam)

            self.features_per_wp[naam] = laag

    def __status_update(self, text):
        self.__gui.btnCyientExport.setText(text)


class Wijkpunt:
    def __init__(self, wijkpunt_feature):
        self.dg = wijkpunt_feature['DG']
        self.wp = wijkpunt_feature['WP']
        self.pop = wijkpunt_feature['POP']

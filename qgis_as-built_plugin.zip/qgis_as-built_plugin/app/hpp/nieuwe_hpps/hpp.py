# hulp imports
import os

# qt imports
from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import QDate

# qgis imports
from qgis.core import (
    QgsApplication, QgsTask, Qgis, QgsMessageLog, QgsProject, QgsFeatureRequest, QgsLayerTreeLayer, QgsMarkerSymbol,
    QgsVectorLayer
)
from qgis.utils import iface

# interne imports
from ...asbuilt.aantallen import ProjectLagen
from ...asbuilt.processing_ import Processing

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'nieuwe_hpps.ui'))


class NieuweHPPsLaag:
    def __init__(self, laag: QgsVectorLayer = None):
        self.laag = None
        self.aantal_features = 0
        self.__naam = 'Nieuwe HPP units'

        self.ingeladen = self.__laag_is_aanwezig_in_het_project()

        if laag is None:
            if self.ingeladen:
                self.laag = QgsProject.instance().mapLayersByName(self.__naam)[0]
            else:
                self.laag = QgsVectorLayer('LineString?crs=epsg:31370', self.__naam, 'memory')
        else:
            self.laag = laag
            self.__styling()
            self.laag.setName(self.__naam)

        self.aantal_features = self.laag.featureCount()

    def __laag_is_aanwezig_in_het_project(self) -> bool:
        if len(QgsProject.instance().mapLayersByName(self.__naam)) == 0:
            return False
        else:
            return True

    def __styling(self):
        instellingen = {
            'angle': '0',
            'cap_style': 'square',
            'color': '178, 223, 138, 255',
            'horizontal_anchor_point': '1',
            'joinstyle': 'bevel',
            'name': 'circle',
            'offset': '0,0',
            'offset_map_unit_scale': '3x:0,0,0,0,0,0',
            'offset_unit': 'MapUnit',
            'outline_color': '35,35,35,255',
            'outline_style': 'solid',
            'outline_width': '0',
            'outline_width_map_unit_scale': '3x:0,0,0,0,0,0',
            'outline_width_unit': 'MapUnit',
            'scale_method': 'diameter',
            'size': '6',
            'size_map_unit_scale': '3x:0,0,0,0,0,0',
            'size_unit': 'Millimeters',
            'vertical_anchor_point': '1'
        }

        self.laag.renderer().setSymbol(QgsMarkerSymbol.createSimple(instellingen))

    def toevoegen_aan_het_project(self):
        # indien de laag al bestaat in het project deze eerst verwijderen
        nieuwe_hpps_laag = [laag.id() for laag in QgsProject.instance().mapLayersByName('Nieuwe HPP units')]
        if not len(nieuwe_hpps_laag) == 0:
            QgsProject.instance().removeMapLayers(nieuwe_hpps_laag)

        # laag toevoegen aan het project
        QgsProject.instance().addMapLayer(self.laag, False)

        # hpp map object zoeken
        hpp_folder = [folder for folder in QgsProject.instance().layerTreeRoot().children() if folder.name() == 'HPP'][0]

        # laag toevoegen aan hpp map
        hpp_folder.insertChildNode(0, QgsLayerTreeLayer(self.laag))


class GUI_HPPsAfmelden(QtWidgets.QMainWindow, FORM_CLASS, ):
    def __init__(self, parent=None):
        super(GUI_HPPsAfmelden, self).__init__(parent)

        self.setupUi(self)

        self.lblAantal.setText(str(NieuweHPPsLaag().aantal_features))
        self.progressBarNieuw.setVisible(False)
        self.progressBarToevoegen.setVisible(False)
        self.progressBarVerwijderen.setVisible(False)
        self.progressBarAfmelden.setVisible(False)
        self.btnNieuw.clicked.connect(self.__nieuw)
        self.btnToevoegen.clicked.connect(self.__toevoegen)
        self.btnVerwijderen.clicked.connect(self.__verwijderen)
        self.btnAfmelden.clicked.connect(self.__afmelden)

        self.taken = QgsApplication.taskManager()

    def __nieuw(self):
        nieuwe_hpps_bepalen = NieuweHPPs(
            "nieuwe hpp's bepalen",
            self
        )

        self.taken.addTask(nieuwe_hpps_bepalen)

    def __toevoegen(self):
        extra_hpps_toevoegen = Toevoegen(
            "extra hpp's toevoegen",
            self
        )

        self.taken.addTask(extra_hpps_toevoegen)

    def __verwijderen(self):
        nieuwe_hpps_laag = NieuweHPPsLaag()

        if nieuwe_hpps_laag.ingeladen:
            if nieuwe_hpps_laag.laag.selectedFeatureCount() > 0:
                if nieuwe_hpps_laag.laag.isEditable() is False:
                    nieuwe_hpps_laag.laag.startEditing()
                nieuwe_hpps_laag.laag.deleteSelectedFeatures()
                nieuwe_hpps_laag.laag.commitChanges()

            self.lblAantal.setText(str(nieuwe_hpps_laag.laag.featureCount()))
            nieuwe_hpps_laag.laag.removeSelection()

    def __afmelden(self):
        hpps_afmelden = Afmelden(
            "hpp's afmelden",
            self
        )

        self.taken.addTask(hpps_afmelden)


class NieuweHPPs(QgsTask, ProjectLagen, Processing):
    def __init__(self, description, gui):

        super().__init__(description, QgsTask.CanCancel)

        self.__gui = gui
        self.__laag = None

        self.__btn_text = self.__gui.btnNieuw.text()

    def run(self):
        """ GUI """
        self.__knoppen_uitschakelen()

        """ BEREKENING """
        # enkel hpps uit wijkpunt zones die niet HPP zijn gebruiken
        self.__laag = self.extract_by_location(self._hpp, self._wijkpunten)
        self.__laag = self.extract_by_expression(
            self.__laag,
            'to_string("HPPlasticCompleted") = \'None\''
        )
        hpp_laag = self.__laag
        self.__status_update(16)

        # om de processing sneller te laten werken, enkel de features gebruiken die in de wijkzones liggen
        self._straten = self.extract_by_location(self._straten, self._wijkpunten)
        self._geolantis_lines = self.extract_by_location(self._geolantis_lines, self._wijkpunten)
        self._facade = self.extract_by_location(self._facade, self._wijkpunten)
        self._facade = Processing().extract_by_expression(self._facade, '"uitgevoerd" is true')
        self.__status_update(33)

        # lijn trekken tussen de unit en dichtsbijzijnde straat
        dichtsbijzijnde_straat_lijnen = self.shortest_line(self.__laag, self._straten)
        dichtsbijzijnde_straat_lijnen = self.delete_duplicates_by_attribute(dichtsbijzijnde_straat_lijnen,
                                                                            ['DHid'])
        self.__status_update(50)

        # alle soorten distributielijnen samenvoegen
        distributie_lijnen = self.merge_vector_layers([self._geolantis_lines, self._facade])
        self.__status_update(67)

        # units met lijnen die kruisen met een distributielijn zijn hpp
        self.__laag = self.extract_by_location(
            dichtsbijzijnde_straat_lijnen, distributie_lijnen, [7])
        self.__status_update(84)

        # hpp units uit hpp laag halen adhv de hpp lijnen
        self.__laag = self.extract_by_location(hpp_laag, self.__laag, [4])
        self.__status_update(100)

        # laag omzetten in een nieuwe hpp laag object
        self.__laag = NieuweHPPsLaag(self.__laag)

        """ GUI """
        # aantal hpp units invullen in het label
        self.__gui.lblAantal.setText(str(self.__laag.aantal_features))

        return True

    def finished(self, result):
        # laag met af te melden units toevoegen aan het project
        self.__laag.toevoegen_aan_het_project()

        self.__knoppen_inschakelen()

    def __status_update(self, percentage: int):
        self.__gui.progressBarNieuw.setValue(percentage)

    def __knoppen_uitschakelen(self):
        self.__gui.btnNieuw.setText('Bliep Bloep Bliep ...')
        self.__gui.btnNieuw.setEnabled(False)
        self.__gui.btnToevoegen.setEnabled(False)
        self.__gui.btnVerwijderen.setEnabled(False)
        self.__gui.btnAfmelden.setEnabled(False)
        self.__gui.progressBarNieuw.setVisible(True)

    def __knoppen_inschakelen(self):
        self.__gui.btnNieuw.setText(self.__btn_text)
        self.__gui.btnNieuw.setEnabled(True)
        self.__gui.btnToevoegen.setEnabled(True)
        self.__gui.btnVerwijderen.setEnabled(True)
        self.__gui.btnAfmelden.setEnabled(True)
        self.__gui.progressBarNieuw.setVisible(False)


class Toevoegen(QgsTask, ProjectLagen, Processing):
    def __init__(self, description, gui):

        super().__init__(description, QgsTask.CanCancel)

        self.__gui = gui
        self.__laag = None

        self.__btn_text = self.__gui.btnToevoegen.text()

    def run(self):
        """ GUI """
        self.__knoppen_uitschakelen()

        """ BEREKENING """
        # geselecteerde units extrageren
        self.__laag = self.extract_selected_features(self._hpp)
        self.__status_update(50)

        if self.__laag.featureCount() == 0:
            return False

        # cheken of nieuwe hpp laag in het project zit
        nieuwe_hpps_laag = NieuweHPPsLaag()
        if nieuwe_hpps_laag.ingeladen is False:
            return False

        # geselecteerde units mergen met de nieuwe hpp laag
        self.__laag = self.merge_vector_layers([self.__laag, nieuwe_hpps_laag.laag])
        self.__status_update(100)

        # laag omzetten in een nieuwe hpp laag object
        self.__laag = NieuweHPPsLaag(self.__laag)

        """ GUI """
        self.__gui.lblAantal.setText(str(self.__laag.aantal_features))

        return True

    def finished(self, result):
        if result:
            # laag met af te melden units toevoegen aan het project
            self.__laag.toevoegen_aan_het_project()

        self._hpp.removeSelection()
        self.__knoppen_inschakelen()

    def __status_update(self, percentage: int):
        self.__gui.progressBarToevoegen.setValue(percentage)

    def __knoppen_uitschakelen(self):
        self.__gui.btnNieuw.setEnabled(False)
        self.__gui.btnToevoegen.setText('Bliep Bloep Bliep ...')
        self.__gui.btnToevoegen.setEnabled(False)
        self.__gui.btnVerwijderen.setEnabled(False)
        self.__gui.btnAfmelden.setEnabled(False)
        self.__gui.progressBarToevoegen.setVisible(True)

    def __knoppen_inschakelen(self):
        self.__gui.btnNieuw.setEnabled(True)
        self.__gui.btnToevoegen.setText(self.__btn_text)
        self.__gui.btnToevoegen.setEnabled(True)
        self.__gui.btnVerwijderen.setEnabled(True)
        self.__gui.btnAfmelden.setEnabled(True)
        self.__gui.progressBarToevoegen.setVisible(False)


class Afmelden(QgsTask, ProjectLagen, Processing):
    def __init__(self, description, gui):

        super().__init__(description, QgsTask.CanCancel)

        self.__gui = gui

        self.__btn_text = self.__gui.btnAfmelden.text()

    def run(self):
        """ GUI """
        self.__knoppen_uitschakelen()

        """ BEREKENING """
        # nieuwe hpp's object aanmaken
        nieuwe_hpps = NieuweHPPsLaag()

        # checken of nieuwe hpp's laag in het project zit
        if nieuwe_hpps.ingeladen is False:
            return False

        # hpp units selecteren die overeen komen met de nieuwe hpp's
        self.select_by_location(self._hpp, nieuwe_hpps.laag)

        # progress bar max instellen als het aantal aan te passen units
        self.__gui.progressBarAfmelden.setRange(0, self._hpp.selectedFeatureCount())

        # kolom id achterhalen
        hpp_completed_kolom_id = self._hpp.fields().indexFromName('HPPlasticCompleted')

        # geselecteerde hpp units aanpassen naar status HPP, door de datum in te vullen
        if self._hpp.isEditable() is False:
            self._hpp.startEditing()

        for feature in self._hpp.selectedFeatures():
            vandaag = QDate.currentDate()
            if feature['HPPlasticCompleted'] == 'None':
                self._hpp.changeAttributeValue(feature.id(), hpp_completed_kolom_id, vandaag)
            self.__status_update(1)

        self._hpp.commitChanges()

        return True

    def finished(self, result):
        self._hpp.removeSelection()
        self.__knoppen_inschakelen()

    def __status_update(self, percentage: int):
        self.__gui.progressBarAfmelden.setValue(percentage)

    def __knoppen_uitschakelen(self):
        self.__gui.btnNieuw.setEnabled(False)
        self.__gui.btnToevoegen.setEnabled(False)
        self.__gui.btnVerwijderen.setEnabled(False)
        self.__gui.btnAfmelden.setText('Bliep Bloep Bliep ...')
        self.__gui.btnAfmelden.setEnabled(False)
        self.__gui.progressBarAfmelden.setVisible(True)

    def __knoppen_inschakelen(self):
        self.__gui.btnNieuw.setEnabled(True)
        self.__gui.btnToevoegen.setEnabled(True)
        self.__gui.btnVerwijderen.setEnabled(True)
        self.__gui.btnAfmelden.setText(self.__btn_text)
        self.__gui.btnAfmelden.setEnabled(True)
        self.__gui.progressBarAfmelden.setVisible(False)

# qgis imports
from qgis.core import QgsProject, QgsVectorLayer, QgsFeatureRequest, QgsFeature

# hulp imports
from datetime import datetime


class Database:
    def __init__(self, zone: QgsVectorLayer, database_naam: str):
        self.__laag: QgsVectorLayer = QgsProject.instance().mapLayersByName(database_naam)[0]
        self.__zone: QgsVectorLayer = zone

        if zone is not None:
            self.__zone_naam: str = self.__zone_naam_uit_zone_halen()
            self.__zone_kolom_id: int = self.__laag.fields().indexFromName(self.__zone_naam)

    def __zone_naam_uit_zone_halen(self) -> str:
        dg = self.__zone.fields().indexFromName('DG')
        wp = self.__zone.fields().indexFromName('WP')
        pop = self.__zone.fields().indexFromName('POP')
        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([dg, wp, pop])

        zone = next(self.__zone.getFeatures(qry))
        return f"{zone['DG']} {zone['WP']} - {zone['POP']}"

    def inlezen(self, data_staat_op_de_eerte_rij: bool = False) -> int:
        datum_kolom_id = self.__laag.fields().indexFromName('datum')

        qry = QgsFeatureRequest().setFlags(
            QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([datum_kolom_id, self.__zone_kolom_id])

        ingelezen_features = self.__laag.getFeatures(qry)

        if data_staat_op_de_eerte_rij:
            return next(ingelezen_features)[self.__zone_naam]

        data_van_vorige_maand = [feature[self.__zone_naam] for feature in ingelezen_features
                                 if feature['datum'].month() == self.__vorige_maand()]

        return data_van_vorige_maand[-1]

    def inlezen_per_datum(self) -> dict:
        datum_kolom_id = self.__laag.fields().indexFromName('datum')

        qry = QgsFeatureRequest().setFlags(
            QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([datum_kolom_id, self.__zone_kolom_id])

        ingelezen_features = self.__laag.getFeatures(qry)

        data_per_maand = {}
        maanden_namen = {
            1: "Januari",
            2: "Februari",
            3: "Maart",
            4: "April",
            5: "Mei",
            6: "Juni",
            7: "Juli",
            8: "Augustus",
            9: "September",
            10: "Oktober",
            11: "November",
            12: "December"
        }

        for feature in ingelezen_features:
            maand = feature['datum'].month()
            jaar = feature['datum'].year()

            key = f'{maanden_namen[maand]} - {jaar}'

            aantal = feature[self.__zone_naam]

            data_per_maand[key] = aantal

        return data_per_maand

    @staticmethod
    def __vorige_maand() -> int:
        huidige_maand = datetime.today().month

        if huidige_maand == 1:
            return 12
        else:
            return huidige_maand - 1

    def wegschrijven(self, data: list) -> None:
        datum_kolom_id = self.__laag.fields().indexFromName('datum')
        data_datum = data[1]

        qry = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes([datum_kolom_id])

        ingelezen_features = self.__laag.getFeatures(qry)

        feature_id = [feature.id() for feature in ingelezen_features if feature['datum'] == data_datum]

        if len(feature_id) == 0:
            self.__nieuw(data)
        else:
            self.__update(feature_id[0], data)

    def __nieuw(self, data: list) -> None:
        nieuwe_entry = QgsFeature()

        nieuwe_entry.setFields(self.__laag.fields())

        nieuwe_entry.setAttributes(data)

        if not self.__laag.isEditable():
            self.__laag.startEditing()

        self.__laag.dataProvider().addFeature(nieuwe_entry)
        self.__laag.updateExtents()

        self.__laag.commitChanges()

    def __update(self, feature_id: int, data: list) -> None:
        if not self.__laag.isEditable():
            self.__laag.startEditing()

        for i in range(2, len(data)):
            self.__laag.changeAttributeValue(feature_id, i, data[i])

        self.__laag.commitChanges()

